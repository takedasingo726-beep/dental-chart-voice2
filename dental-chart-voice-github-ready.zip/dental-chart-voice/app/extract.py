"""
文字起こしテキストから、カルテ下書きに必要な情報を抽出する。

デフォルトでは外部APIを一切使わず、ローカルの辞書ファイル
（app/dictionaries/*.json）とパターンマッチングのみで動作する。

将来的にローカルLLM（Ollama等）で抽出精度を上げたい場合は、
extract_with_llm() を実装して build_karte_draft() から呼び出す形に
差し替えることを想定している。
"""
import json
import re
from pathlib import Path
from typing import List

from app.models import ExtractedMedication, ExtractedSymptom, KarteDraft

DICT_DIR = Path(__file__).parent / "dictionaries"

# アレルギーに関する言及を検知するための簡易パターン
ALLERGY_PATTERNS = [
    r"アレルギー",
    r"アレルギ[ーｰ]?体質",
    r"[はガガ蕁麻疹]が出た",
    r"蕁麻疹",
    r"ラテックス",
    r"金属アレルギー",
]

# 主訴らしき文を拾うための簡易パターン（「〜が痛い」「〜が気になる」等）
CHIEF_COMPLAINT_PATTERNS = [
    r"[^。、\n]*(痛い|痛む|しみる|腫れ|気になる|取れた|外れた)[^。、\n]*[。、]?",
]


def _load_dict(filename: str) -> dict:
    with open(DICT_DIR / filename, encoding="utf-8") as f:
        return json.load(f)


def extract_symptoms(text: str) -> List[ExtractedSymptom]:
    data = _load_dict("symptoms.json")
    found: List[ExtractedSymptom] = []
    seen_normalized = set()

    for entry in data["entries"]:
        for synonym in entry["synonyms"]:
            if synonym in text:
                if entry["normalized"] not in seen_normalized:
                    found.append(
                        ExtractedSymptom(
                            normalized=entry["normalized"], mentioned_as=synonym
                        )
                    )
                    seen_normalized.add(entry["normalized"])
                break
    return found


def extract_medications(text: str) -> List[ExtractedMedication]:
    data = _load_dict("medications.json")
    found: List[ExtractedMedication] = []
    seen_categories = set()

    for entry in data["entries"]:
        for keyword in entry["keywords"]:
            if keyword in text:
                if entry["category"] not in seen_categories:
                    found.append(
                        ExtractedMedication(
                            category=entry["category"], mentioned_as=keyword
                        )
                    )
                    seen_categories.add(entry["category"])
                break
    return found


def extract_allergy_mentions(text: str) -> List[str]:
    mentions = []
    for pattern in ALLERGY_PATTERNS:
        for match in re.finditer(pattern, text):
            # 前後の文脈を少し含めて記録（人手確認しやすくするため）
            start = max(0, match.start() - 10)
            end = min(len(text), match.end() + 15)
            snippet = text[start:end]
            if snippet not in mentions:
                mentions.append(snippet)
    return mentions


def guess_chief_complaint(text: str) -> str | None:
    """
    会話の中から主訴らしき一文を推定する。
    非常に単純なヒューリスティックのため、精度は限定的。
    歯科医師による確認・修正を前提とする。
    """
    for pattern in CHIEF_COMPLAINT_PATTERNS:
        match = re.search(pattern, text)
        if match:
            return match.group(0).strip()
    return None


def extract_with_llm(text: str) -> dict | None:
    """
    ローカルLLM（例: Ollama）を使った高精度抽出のための拡張ポイント。

    デフォルトでは未実装（None を返す = 使用しない）。
    実装する場合の例:

        import requests
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={
                "model": "elyza:jp",
                "prompt": f"以下の歯科診察の会話から、症状・服薬情報をJSONで抽出して:\\n{text}",
                "stream": False,
            },
        )
        return json.loads(response.json()["response"])

    ※ 外部クラウドLLM APIを使う場合は、患者の会話データを
      外部送信することになるため、院内のプライバシーポリシー・
      個人情報保護法の要件を必ず確認してください。
    """
    return None


def build_karte_draft(raw_transcript: str) -> KarteDraft:
    """文字起こし全文からカルテ下書きを組み立てるメイン関数。"""
    symptoms = extract_symptoms(raw_transcript)
    medications = extract_medications(raw_transcript)
    allergy_mentions = extract_allergy_mentions(raw_transcript)
    chief_complaint = guess_chief_complaint(raw_transcript)

    other_notes = []
    if not symptoms:
        other_notes.append("症状に関するキーワードが検出されませんでした。手動で確認してください。")
    if not medications:
        other_notes.append("服薬に関する言及が検出されませんでした（未確認/服薬なしの可能性）。")

    return KarteDraft(
        chief_complaint=chief_complaint,
        symptoms=symptoms,
        current_medications=medications,
        allergy_mentions=allergy_mentions,
        other_notes=other_notes,
        raw_transcript=raw_transcript,
    )
