"""
faster-whisper によるローカル音声文字起こし。

外部API・クラウドサービスへの音声送信は行わない。
初回実行時にモデルファイルがローカルにダウンロード・キャッシュされ、
以降はオフラインで動作する。
"""
from functools import lru_cache
from pathlib import Path

from faster_whisper import WhisperModel

# モデルサイズ: tiny / base / small / medium / large-v3
# 精度と速度のバランスを見て変更してください。
MODEL_SIZE = "small"

# GPU がある環境では "cuda" に変更すると高速化されます。
DEVICE = "cpu"
COMPUTE_TYPE = "int8"  # CPU実行時の省メモリ・高速化設定


@lru_cache(maxsize=1)
def _get_model() -> WhisperModel:
    """モデルをプロセス内で使い回す（毎回ロードすると遅いため）。"""
    return WhisperModel(MODEL_SIZE, device=DEVICE, compute_type=COMPUTE_TYPE)


def transcribe_audio(file_path: str, language: str = "ja") -> str:
    """
    音声ファイルを文字起こしする。

    Args:
        file_path: 音声ファイルのパス（wav/mp3/m4a等、ffmpegが対応する形式）
        language: 言語コード（デフォルト日本語）

    Returns:
        文字起こし結果の全文テキスト
    """
    if not Path(file_path).exists():
        raise FileNotFoundError(f"音声ファイルが見つかりません: {file_path}")

    model = _get_model()
    segments, _info = model.transcribe(
        file_path,
        language=language,
        vad_filter=True,  # 無音区間を除去し精度・速度を改善
    )

    full_text = "".join(segment.text for segment in segments)
    return full_text.strip()
