# dental-chart-voice

歯科医師と患者の会話（録音データ）から、カルテ作成に必要な情報
（主訴・症状・現在服用中の薬・アレルギー等）を自動抽出し、
構造化されたカルテ下書きを生成するプロトタイプアプリです。

> ⚠️ **重要な注意事項**
> - 本ツールは**カルテ作成の下書き支援**を目的としたプロトタイプであり、医療機器・診断支援ツールではありません。
> - 生成された内容は必ず歯科医師本人が確認・修正した上でカルテに反映してください。抽出結果をそのまま正式なカルテとして採用しないでください。
> - 患者の音声・会話内容は機微な個人情報（要配慮個人情報）です。院内での録音・保存・利用にあたっては、患者への説明と同意取得、施設のプライバシーポリシー、個人情報保護法等の関連法規を遵守してください。
> - 本リポジトリはローカル環境での完結を前提に設計されていますが、実運用前に必ずセキュリティレビューを行ってください。

## 特徴

- **音声認識はローカル完結**: [faster-whisper](https://github.com/SYSTRAN/faster-whisper) を使用し、音声データを外部API・クラウドに送信しません。
- **処理方式**: 診察後にまとめてアップロードし、バッチで文字起こし・情報抽出を行う方式（リアルタイム処理ではありません）。
- **情報抽出はルールベース＋辞書ベース**: 症状・薬剤名の辞書とパターンマッチングにより、外部LLM APIを使わずに抽出します（辞書は `app/dictionaries/` で自由にカスタマイズ可能）。
- **拡張ポイント**: `app/extract.py` の `extract_with_llm()` は、Ollama等の**ローカルLLM**に差し替えるためのフック（デフォルトでは未使用）。外部クラウドLLM APIを使う場合は、プライバシー要件を再検討した上で有効化してください。

## ディレクトリ構成

```
dental-chart-voice/
├── app/
│   ├── main.py              # FastAPIアプリ本体（エンドポイント定義）
│   ├── transcribe.py        # faster-whisperによるローカル文字起こし
│   ├── extract.py           # 症状・服薬などの抽出ロジック
│   ├── models.py            # カルテ構造のPydanticモデル
│   ├── dictionaries/
│   │   ├── symptoms.json    # 症状キーワード辞書
│   │   └── medications.json # 薬剤名キーワード辞書
│   └── templates/
│       └── index.html       # アップロード・確認画面
├── static/
│   └── style.css
├── tests/
│   └── test_extract.py
├── sample_audio/             # テスト用音声を置く場所（空）
├── requirements.txt
└── README.md
```

## セットアップ

```bash
# 1. 仮想環境作成（推奨）
python -m venv venv
source venv/bin/activate  # Windowsは venv\Scripts\activate

# 2. 依存パッケージインストール
pip install -r requirements.txt

# 3. FFmpegが必要です（音声デコード用）
# Mac:   brew install ffmpeg
# Ubuntu: sudo apt install ffmpeg
# Windows: https://ffmpeg.org/download.html からダウンロードしPATHに追加

# 4. アプリ起動
uvicorn app.main:app --reload
```

起動後、ブラウザで `http://127.0.0.1:8000` にアクセスしてください。

初回起動時、faster-whisperが指定モデル（デフォルト: `small`）を自動ダウンロードします
（以降はローカルにキャッシュされ、オフラインで動作します）。

## 使い方

1. トップページで診察の録音ファイル（wav/mp3/m4a等）をアップロード
2. 「解析する」を押すと、文字起こし→情報抽出が実行される
3. 主訴・症状・服薬情報などが構造化されたフォームに自動入力される
4. **歯科医師が内容を確認・修正**し、JSON形式でダウンロード（または院内システムへの連携用に加工）

## モデルサイズの変更

`app/transcribe.py` の `MODEL_SIZE` を変更してください。

| モデル | 精度 | 速度 | 用途 |
|---|---|---|---|
| tiny / base | 低 | 速い | 動作確認用 |
| small（デフォルト） | 中 | 中 | 実用バランス |
| medium / large-v3 | 高 | 遅い | GPU推奨、精度重視 |

GPUがある場合は `app/transcribe.py` の `device="cuda"` に変更すると高速化されます。

## 辞書のカスタマイズ

`app/dictionaries/symptoms.json` と `medications.json` を編集することで、
歯科特有の表現や院内でよく使う薬剤名を追加・調整できます。
フォーマットは各ファイル内のコメント例を参照してください。

## テスト

ローカルでは次のコマンドでテストできます。

```bash
pip install pytest
pytest
```

GitHubにpushすると、`.github/workflows/tests.yml` によりGitHub Actionsでも自動テストされます。

## ライセンス

MIT License（`LICENSE` ファイルを追加してご利用ください）
